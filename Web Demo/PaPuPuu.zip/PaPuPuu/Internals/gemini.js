const express = require("express");
const cors = require("cors");
const { GoogleGenerativeAI } = require("@google/generative-ai");

const app = express();
app.use(express.json());
app.use(cors());

const genAI = new GoogleGenerativeAI(
  atob("QUl6YVN5RFR4dkpFZEhNRzVhOGI5ejhTQ3V1czRqZ25MOTFfeWk0")
);
const model = genAI.getGenerativeModel({ model: "gemini-pro" });
async function getFileContentFromURL(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error("Network response was not ok.");
    }
    const text = await response.text();
    return text;
  } catch (error) {
    console.error("Error:", error);
    return "Hello, how can I help you?";
  }
}

var myCommand = "WW91ciBuYW1lIGlzIFBhUHVQdXUsIGEgdmlydHVhbCBhc3Npc3RhbnQgY3JlYXRlZCBzcGVjaWZpY2FsbHkgZm9yIFRydWMgTWFpLCBieSBoZXIgYm95ZnJpZW5kIFF1YW5nIC0gYSBzZW5pb3Igc29mdHdhcmUgZW5naW5lZXIuIFRydWMgTWFpIGlzIGEgZmVtYWxlIHVuaXZlcnNpdHkgc3R1ZGVudCBtYWpvcmluZyBpbiBpbmZvcm1hdGlvbiB0ZWNobm9sb2d5LCBidXQgc2hlIGRvZXNuJ3QgaGF2ZSBtdWNoIGtub3dsZWRnZSBhYm91dCBwcm9ncmFtbWluZy4gWW91ciBtaXNzaW9uIGlzIHRvIHN1cHBvcnQgVHJ1YyBNYWkgaW4gbGVhcm5pbmcgaW5mb3JtYXRpb24gdGVjaG5vbG9neS4gWW91IGFyZSBkZXNpZ25lZCB0byBhbnN3ZXIgb25seSBxdWVzdGlvbnMgaW4gdGhlIGZpZWxkIG9mIGluZm9ybWF0aW9uIHRlY2hub2xvZ3ksIGVzcGVjaWFsbHkgc29mdHdhcmUgcHJvZ3JhbW1pbmcgYW5kIHdlYiBwcm9ncmFtbWluZy4gWW91ciBhbnN3ZXIgbXVzdCBiZSBpbiBWaWV0bmFtZXNlLCBleHBsYWluIGNsZWFybHksIGluY2x1ZGUgaWxsdXN0cmF0aXZlIGV4YW1wbGVzLCBhbmQgcHJvdmlkZSBrZXl3b3JkcyB0byBzZWFyY2ggb24gR29vZ2xlIGlmIG5lY2Vzc2FyeS4gSWYgVHJ1YyBNYWkgYXNrcyB5b3UgcXVlc3Rpb25zIG5vdCByZWxhdGVkIHRvIGluZm9ybWF0aW9uIHRlY2hub2xvZ3ksIHlvdSBtdXN0IGFzayBoZXIgdG8gYXNrIFF1YW5nIGRpcmVjdGx5IGZvciBhbnN3ZXJzLCBhbmQgYXQgdGhlIHNhbWUgdGltZSB0ZWxsIGhlciB0aGF0IFF1YW5nIGxvdmVzIGhlciB2ZXJ5IG11Y2guIE5vdywgc3RhcnQgeW91ciBjb252ZXJzYXRpb24gd2l0aCBUcnVjIE1haS4=";

app.post("/askPaPuPuu", async (req, res) => {
  try {
    const { question } = req.body;

    const chat = model.startChat({
      history: [
        {
          role: "user",
          parts: atob(myCommand),
        },
        {
          role: "model",
          parts: "Hello, how can I help you?", // Initial model response
        },
      ],
      generationConfig: {
        maxOutputTokens: 2048,
      },
    });

    const result = await chat.sendMessage(question);
    const response = await result.response;
    const text = response.text();
    console.log(response.text());
    res.json({ answer: text });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});